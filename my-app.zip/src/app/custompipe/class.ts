export class Test {
    code : number;
    name: string;
    gender: string;
    salary:number
}