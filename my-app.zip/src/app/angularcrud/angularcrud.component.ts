import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angularcrud',
  templateUrl: './angularcrud.component.html',
  styleUrls: ['./angularcrud.component.scss']
})
export class AngularcrudComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
